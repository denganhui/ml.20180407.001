#!/usr/bin python3 

from fact import factorial
__all__ = [factorial,]
